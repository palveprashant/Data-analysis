Data Science & Business Analytics Task (The Sparks Foundation)
#Task2
TSF task 2 (Data Science and Business Analyst Internship)
From the given ‘Iris’ dataset, I predicted the optimum number of clusters and represented it visually.
I used Python to perform this task.
